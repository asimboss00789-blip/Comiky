# manga reader

A Pen created on CodePen.

Original URL: [https://codepen.io/Asim-Boss-the-decoder/pen/bNVmaKz](https://codepen.io/Asim-Boss-the-decoder/pen/bNVmaKz).

